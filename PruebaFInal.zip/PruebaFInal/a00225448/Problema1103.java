import java.util.*;
import java.io.*;
public class Problema1103{
	
	public static void main(String []args){
		BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
	
		try{
			int a= Integer.parseInt(stdin.readLine());
			String palabras[];
			int cont=0;
			for(int i=0; i<a; i++){
				palabras = entrada.readLine().split(" ");
				cont+=palabras.length;
				System.out.println("Frase: "+(i+1)+": "+palabras.length+" palabras");
			}
			
			System.out.println("Total "+cont+" palabras");
		}
		catch(IOException io){
		System.out.println("Error");
		}
	}
}