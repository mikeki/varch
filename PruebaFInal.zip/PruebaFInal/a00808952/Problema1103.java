   import java.util.*;
   import java.io.*;

    public class Problema1103 {
   
       public static void main (String [] args) throws IOException {
         BufferedReader stdin = new BufferedReader (new InputStreamReader (System.in));
         int bla = Integer.parseInt(stdin.readLine());
         String arr[] = new String [bla];
      
         for (int i=0; i<bla; i++) {
            String oracion = stdin.readLine ();
            oracion = oracion.trim();
            arr[i]=oracion; }
      
         int suma=0;
         int cont=1;
      
         for (int k=0; k<arr.length; k++) {
            for (int j=0; j<arr[k].length(); j++) {
               if (arr[k].charAt(j) == ' ' && arr[k].charAt(j-1) != ' ') {
                  cont++;
               }
            }
         
            suma = suma+cont;
            System.out.println ("Frase " + (k+1) + ": "+ cont+ " palabras");
            cont=1;
         }
      
         System.out.println ("Total: " + suma+ " palabras");
      }
   }