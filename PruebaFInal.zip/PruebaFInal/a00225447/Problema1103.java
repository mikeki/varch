import java.util.*;
import java.io.*;
public class Problema1103{
	
	public static void main(String []args){
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		//Scanner stdin2 = new Scanner(System.in);
		try{
			int n= Integer.parseInt(stdin.readLine());
			String palabras[];
			int cont=0;
			for(int i=0; i<n; i++){
				palabras = stdin.readLine().split(" ");
				cont+=palabras.length;
				System.out.println("Frase "+(i+1)+": "+palabras.length+" palabras");
			}
			
			System.out.println("Total: "+cont+" palabras");
		}
		catch(IOException io){
		System.out.println("Error");
		}
	}
}