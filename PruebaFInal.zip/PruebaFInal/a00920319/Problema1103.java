import java.util.*;
   import java.io.*;

   public class Problema1103 {
   
      public static void main (String [] args)throws IOException{
         //Scanner stdin = new Scanner (System.in);
         //Scanner stdin2 = new Scanner (System.in);
         BufferedReader stdin = new BufferedReader (new InputStreamReader(System.in));
         int qtyf = Integer.parseInt(stdin.readLine());
         String arr[] = new String [qtyf];
      
         for (int i=0; i<qtyf; i++){
            String frases = stdin.readLine();
            frases = frases.trim();
            arr[i]=frases;}
      		
         int suma =0; 
         int cont = 1;
         for (int z=0; z<arr.length; z++){
            for (int j=0; j<arr[z].length(); j++){
               if (arr[z].charAt(j) == ' ' && arr[z].charAt(j-1) != ' '){
                  cont++;}
             
            } 
            suma = suma + cont;
            System.out.println ("Frase "+ (z+1) + ": "+ cont + " palabras");
            cont =1;
         }
         System.out.println ("Total: " + suma+ " palabras");
      }
   }