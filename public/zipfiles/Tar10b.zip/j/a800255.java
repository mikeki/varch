import java.util.*;

public class TareaArreglos{

public String concatenaNegativos(int arr1[]){
 int contN = 0;
  for(int i = 0; i > arr.length; i++)
   if(arr[i]<0)
	 contN++;
	else
	 return error;
	 System.out.println("Negativos:" + contN);
  }
 	 
 public static void cambiaACero(double arr2[]){
  double arr2[] = 0;
   for(i = 0; i < arr.length; i++){
	 if(arr2[i]>0)
	  return 0;
  }
  despliega double (arr2[]);	  
 }	  
     
 public boolean Intercala(int a[],int b[], int c[]){
  if(a.length != 2 && b.length != 4 && c.length != 6){
   return false;
  else 
   return true;
 }
  despliega boolean (arr[])
 }
  
  
 		 
	 
	 
	 
	 
	  
      